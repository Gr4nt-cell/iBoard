#!/system/bin/sh
# Runs early in boot, before Android loads fonts.
# Android 12+ can download an updated emoji font into /data/fonts and use it instead of
# /system/fonts. Those files are write-protected, so remove them; Android then falls back
# to the system emoji font, which this module replaces with AURA.
MODDIR=${0%/*}
if [ -d /data/fonts/files ]; then
  for f in $(find /data/fonts/files -iname '*emoji*' 2>/dev/null); do
    rm -rf "$(dirname "$f")"
  done
  rm -f /data/fonts/config/config.xml
fi
