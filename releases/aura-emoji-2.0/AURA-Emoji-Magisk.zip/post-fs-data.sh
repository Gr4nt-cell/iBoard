#!/system/bin/sh
# Runs early in boot, before Android loads fonts.
MODDIR=${0%/*}
FONT="$MODDIR/system/fonts/NotoColorEmoji.ttf"
SIZE=$(stat -c %s "$FONT")

# 1) Android 12+ can download an updated emoji font into /data/fonts and prefer it over
#    /system/fonts. Remove it so the system emoji font is used.
if [ -d /data/fonts/files ]; then
  for f in $(find /data/fonts/files -iname '*emoji*' 2>/dev/null); do rm -rf "$(dirname "$f")"; done
  rm -f /data/fonts/config/config.xml
fi

# 2) Put AURA over every system emoji font. The root manager normally does this from the
#    module's system/ folder; if it didn't (e.g. KernelSU without a mount metamodule),
#    bind-mount the font ourselves.
chcon u:object_r:system_file:s0 "$FONT" 2>/dev/null
chmod 644 "$FONT"
for dir in /system/fonts /product/fonts /system_ext/fonts; do
  [ -d "$dir" ] || continue
  for f in "$dir"/*[Ee]moji*.tt[fc]; do
    [ -f "$f" ] || continue
    case "$(basename "$f")" in *Flags*) continue ;; esac
    [ "$(stat -c %s "$f")" = "$SIZE" ] && continue
    mount -o bind "$FONT" "$f" && echo "bind $f" >> "$MODDIR/mount.log"
  done
done
