AURA Emoji system font (for rooted phones)

Install: Magisk (or KernelSU / APatch) > Modules > Install from storage > pick this zip > Reboot.
Remove:  Modules > AURA Emoji > Remove > Reboot.

1652 emoji are AURA (iBoard's own Figma-made set). Everything else uses
Google's Noto 3D emoji (SIL Open Font License, see LICENSE-Noto-OFL.txt).
WhatsApp, Facebook, Messenger and some others draw their own emoji and won't change.
