#!/system/bin/sh
# After boot: replace the emoji font copies kept by Google Play services (used by apps
# that load "downloadable" emoji), and stop Play services from downloading a new one.
MODDIR=${0%/*}
FONT="$MODDIR/system/fonts/NotoColorEmoji.ttf"
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
sleep 8
sh "$MODDIR/apply.sh" >/dev/null 2>&1
