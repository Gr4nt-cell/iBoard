#!/system/bin/sh
# Apps using Google's downloadable emoji (EmojiCompat) read a copy kept by Play services.
# Swap that copy for AURA after each boot.
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
sleep 5
FONT="$MODDIR/system/fonts/NotoColorEmoji.ttf"
for d in /data/data/com.google.android.gms/files/fonts/opentype /data/fonts/files; do
  [ -d "$d" ] || continue
  find "$d" -iname '*emoji*.ttf' 2>/dev/null | while read -r f; do
    cmp -s "$FONT" "$f" || { cp -f "$FONT" "$f"; chmod 644 "$f"; }
  done
done
