#!/system/bin/sh
# Replace emoji fonts that apps keep in their own storage with AURA.
MODDIR=${0%/*}
FONT="$MODDIR/system/fonts/NotoColorEmoji.ttf"
n=0
put() { # put <target> : copy AURA over target, keep the app's owner and SELinux label
  t="$1"; d=$(dirname "$t")
  own=$(stat -c %u:%g "$d" 2>/dev/null); ctx=$(ls -Zd "$d" 2>/dev/null | awk '{print $1}')
  chattr -i "$t" 2>/dev/null
  cmp -s "$FONT" "$t" && return
  cp -f "$FONT" "$t" || return
  [ -n "$own" ] && chown "$own" "$t"; chmod 644 "$t"
  case "$ctx" in u:*) chcon "$ctx" "$t" ;; esac
  n=$((n+1))
}
# Any emoji font file an app keeps (Play services, Facebook, Messenger, others).
for f in $(find /data/data /data/user/*/ -maxdepth 6 -iname '*emoji*.tt[fc]' 2>/dev/null | grep -v '/data/adb/'); do put "$f"; done
# Facebook / Messenger load this file; create it if missing and make it read-only.
for pkg in com.facebook.orca com.facebook.katana com.facebook.lite com.facebook.mlite; do
  [ -d /data/data/$pkg ] || continue
  mkdir -p /data/data/$pkg/app_ras_blobs
  chown $(stat -c %u:%g /data/data/$pkg) /data/data/$pkg/app_ras_blobs
  put /data/data/$pkg/app_ras_blobs/FacebookEmoji.ttf; chmod 444 /data/data/$pkg/app_ras_blobs/FacebookEmoji.ttf
  rm -rf /data/data/$pkg/files/fonts; mkdir -p /data/data/$pkg/files/fonts; chmod 000 /data/data/$pkg/files/fonts
  am force-stop $pkg 2>/dev/null
done
# Stop Play services from downloading a new emoji font over AURA.
pm disable com.google.android.gms/com.google.android.gms.fonts.update.UpdateSchedulerService >/dev/null 2>&1
echo "$n"
