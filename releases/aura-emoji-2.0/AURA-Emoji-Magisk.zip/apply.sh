#!/system/bin/sh
MODDIR=${0%/*}
FONT="$MODDIR/system/fonts/NotoColorEmoji.ttf"
n=0
for d in /data/data/com.google.android.gms/files/fonts /data/user/*/com.google.android.gms/files/fonts /data/fonts/files; do
  [ -d "$d" ] || continue
  for f in $(find "$d" -iname '*emoji*.ttf' 2>/dev/null); do
    if ! cmp -s "$FONT" "$f"; then
      own=$(stat -c %u:%g "$f" 2>/dev/null)
      cp -f "$FONT" "$f" 2>/dev/null && chmod 644 "$f" && [ -n "$own" ] && chown "$own" "$f"
      n=$((n+1))
    fi
  done
done
echo "$n"
