# Put the AURA font in place of every emoji font this phone has.
FONT="$MODPATH/system/fonts/NotoColorEmoji.ttf"
ui_print "- AURA Emoji: looking for emoji fonts"
for dir in /system/fonts /system/product/fonts /product/fonts /system_ext/fonts; do
  [ -d "$dir" ] || continue
  for f in "$dir"/*Emoji*.ttf "$dir"/*emoji*.ttf; do
    [ -f "$f" ] || continue
    name=$(basename "$f")
    case "$name" in *Flags*) continue ;; esac   # keep the separate flags font if the ROM has one
    case "$dir" in
      /system/*) dest="$MODPATH$dir" ;;
      *) dest="$MODPATH/system$dir" ;;
    esac
    mkdir -p "$dest"
    [ "$dest/$name" = "$FONT" ] || cp -f "$FONT" "$dest/$name"
    ui_print "  replaced $dir/$name"
  done
done
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
ui_print "- Reboot to see AURA emoji"
