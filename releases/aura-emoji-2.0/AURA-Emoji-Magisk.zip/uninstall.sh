#!/system/bin/sh
# Let Play services download its own emoji font again.
find /data/data/com.google.android.gms/files/fonts/opentype -iname '*emoji*.ttf' -delete 2>/dev/null
