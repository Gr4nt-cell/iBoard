#!/system/bin/sh
# Tap "Action" on the AURA Emoji module in Magisk / KernelSU to run this check.
MODDIR=${0%/*}
FONT="$MODDIR/system/fonts/NotoColorEmoji.ttf"
SIZE=$(stat -c %s "$FONT")
echo "AURA Emoji check"
echo "Android $(getprop ro.build.version.release), $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "ROM: $(getprop ro.build.display.id)"
echo ""
echo "System emoji fonts (AURA = $SIZE bytes):"
for f in /system/fonts/*moji* /system/fonts/*Moji* /product/fonts/*moji* /product/fonts/*Moji* /system_ext/fonts/*moji* /system_ext/fonts/*Moji*; do
  [ -f "$f" ] || continue
  s=$(stat -c %s "$f"); t="other"; [ "$s" = "$SIZE" ] && t="AURA"
  echo "  $t  $f"
done
echo ""
echo "Downloaded emoji fonts (/data/fonts):"
find /data/fonts -iname '*moji*' 2>/dev/null | sed 's/^/  /'
[ -z "$(find /data/fonts -iname '*moji*' 2>/dev/null)" ] && echo "  none"
echo ""
echo "Google Play services emoji fonts:"
find /data/data/com.google.android.gms/files/fonts -iname '*moji*' 2>/dev/null | while read -r f; do
  s=$(stat -c %s "$f"); t="other"; [ "$s" = "$SIZE" ] && t="AURA"; echo "  $t  $f"
done
echo ""
echo "Emoji font Android is set to use:"
for x in /system/etc/fonts.xml /system/etc/font_fallback.xml /product/etc/fonts_customization.xml; do
  [ -f "$x" ] && grep -io '[A-Za-z_-]*emoji[A-Za-z_-]*\.tt[fc]' "$x" | sort -u | sed "s|^|  $(basename $x): |"
done
echo ""
echo "Replacing Play services copies again: $(sh $MODDIR/apply.sh) file(s) updated."
echo "If anything above says 'other', send a screenshot of this screen."
