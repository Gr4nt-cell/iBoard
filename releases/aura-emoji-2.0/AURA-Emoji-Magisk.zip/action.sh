#!/system/bin/sh
# Tap "Action" on the AURA Emoji module in Magisk / KernelSU to run this check.
MODDIR=${0%/*}
FONT="$MODDIR/system/fonts/NotoColorEmoji.ttf"
SIZE=$(stat -c %s "$FONT")
echo "AURA Emoji check"
echo "Android $(getprop ro.build.version.release), $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "ROM: $(getprop ro.build.display.id)"
if [ -d /data/adb/ksu ]; then echo "Root: KernelSU $(cat /data/adb/ksu/version 2>/dev/null)"; elif [ -d /data/adb/ap ]; then echo "Root: APatch"; else echo "Root: Magisk $(magisk -v 2>/dev/null)"; fi
echo "Font mounts: $(grep -c -i emoji /proc/mounts)"
echo ""
echo "System emoji fonts (AURA = $SIZE bytes):"
for f in /system/fonts/*moji* /system/fonts/*Moji* /product/fonts/*moji* /product/fonts/*Moji* /system_ext/fonts/*moji* /system_ext/fonts/*Moji*; do
  [ -f "$f" ] || continue
  s=$(stat -c %s "$f"); t="other"; [ "$s" = "$SIZE" ] && t="AURA"
  echo "  $t  $f"
done
echo ""
echo "Downloaded emoji fonts (/data/fonts):"
find /data/fonts -iname '*moji*' 2>/dev/null | sed 's/^/  /'
[ -z "$(find /data/fonts -iname '*moji*' 2>/dev/null)" ] && echo "  none"
echo ""
echo "Google Play services emoji fonts:"
find /data/data/com.google.android.gms/files/fonts -iname '*moji*' 2>/dev/null | while read -r f; do
  s=$(stat -c %s "$f"); t="other"; [ "$s" = "$SIZE" ] && t="AURA"; echo "  $t  $f"
done
echo ""
echo "Emoji font Android is set to use:"
for x in /system/etc/fonts.xml /system/etc/font_fallback.xml /product/etc/fonts_customization.xml; do
  [ -f "$x" ] && grep -io '[A-Za-z_-]*emoji[A-Za-z_-]*\.tt[fc]' "$x" | sort -u | sed "s|^|  $(basename $x): |"
done
echo ""
echo "Emoji files inside apps:"
for f in $(find /data/data -maxdepth 6 -iname '*emoji*' 2>/dev/null | grep -v -e com.google.android.gms -e '/cache/' | head -40); do
  s=$(stat -c %s "$f" 2>/dev/null); t="other"; [ "$s" = "$SIZE" ] && t="AURA"; [ -d "$f" ] && t="folder"
  echo "  $t  $f"
done
echo ""
echo "WhatsApp: $( [ -d /data/data/com.whatsapp ] && echo installed || echo not found)"
[ -d /data/data/com.whatsapp ] && find /data/data/com.whatsapp /storage/emulated/0/Android/media/com.whatsapp -maxdepth 4 \( -iname '*emoji*' -o -iname '*.ttf' \) 2>/dev/null | head -20 | sed 's/^/  /'
echo ""
for pkg in org.telegram.messenger org.telegram.messenger.web org.telegram.messenger.beta org.thunderdog.challegram org.telegram.plus; do
  [ -d /data/data/$pkg ] || continue
  echo "Telegram ($pkg): installed"
  find /data/data/$pkg /storage/emulated/0/Android/data/$pkg -maxdepth 4 \( -iname '*emoji*' -o -iname '*.ttf' \) 2>/dev/null | head -15 | sed 's/^/  /'
  grep -l -i -o 'useSystemEmoji[^/]*' /data/data/$pkg/shared_prefs/*.xml 2>/dev/null | head -1 | xargs -r grep -i -o '<boolean name="useSystemEmoji" value="[a-z]*"' | sed 's/^/  /'
done
echo ""
echo "Replacing app emoji files again: $(sh $MODDIR/apply.sh) file(s) updated."
echo "If anything above says 'other', send a screenshot of this screen."
