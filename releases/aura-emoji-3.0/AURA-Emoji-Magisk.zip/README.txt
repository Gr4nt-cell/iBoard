AURA Emoji system font (for rooted phones)

Install: Magisk (or KernelSU / APatch) > Modules > Install from storage > pick this zip > Reboot.
Remove:  Modules > AURA Emoji > Remove > Reboot.

All emoji are AURA (iBoard). Flags are from Google Noto 3D emoji (OFL).
Google's Noto 3D emoji (SIL Open Font License, see LICENSE-Noto-OFL.txt).
WhatsApp, Facebook, Messenger and some others draw their own emoji and won't change.

If emoji still look like Android's after a reboot, open Magisk > Modules > AURA Emoji > Action
(or KernelSU's action button) and send a screenshot of the result.
